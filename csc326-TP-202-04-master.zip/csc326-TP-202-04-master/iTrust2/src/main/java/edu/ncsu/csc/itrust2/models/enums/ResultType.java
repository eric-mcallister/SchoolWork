package edu.ncsu.csc.itrust2.models.enums;

/**
 * All type of results accepted in lab procedures should be included herein
 *
 * @author Rolf Lewis
 *
 */
public enum ResultType {

    /**
     * Qualitative Results
     */
    QUALITATIVE ( 0, "String" ),

    /**
     * Quantitative Result
     */
    QUANTITATIVE ( 1, "Integer" );

    /**
     * Numeric code of the Role
     */
    private int    code;

    /**
     * Landing screen the User should be shown when logging in
     */
    private String resultType;

    /**
     * Create a Role from a code and landing screen.
     *
     * @param code
     *            Code of the Role.
     * @param resultType
     *            String name for the type of the result
     */
    private ResultType ( final int code, final String resultType ) {
        this.code = code;
        this.resultType = resultType;
    }

    /**
     * Gets the numeric code of the Role
     *
     * @return Code of this role
     */
    public int getCode () {
        return this.code;
    }

    /**
     * Gets the landing page for this user
     *
     * @return Landing page for the user
     */
    public String getType () {
        return this.resultType;
    }

    /**
     * Parse the String provided into an actual ResultType enum.
     *
     * @param typeStr
     *            String representation of the type
     * @return Type enum corresponding to the string, or NotSpecified if nothing
     *         could be matched
     */
    public static ResultType parse ( final String typeStr ) {
        for ( final ResultType type : values() ) {
            if ( type.getType().equals( typeStr ) ) {
                return type;
            }
        }
        return null;
    }

}
