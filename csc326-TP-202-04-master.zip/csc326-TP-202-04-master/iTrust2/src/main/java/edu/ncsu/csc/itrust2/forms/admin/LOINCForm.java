package edu.ncsu.csc.itrust2.forms.admin;

import edu.ncsu.csc.itrust2.models.enums.ResultType;
import edu.ncsu.csc.itrust2.models.persistent.LOINC;

/**
 * Intermediate form for adding or editing LOINC codes. Used to create and
 * serialize LOINC codes.
 *
 * @author Thomas Dickerson
 *
 */
public class LOINCForm {

    /** The code of the Lab Procedure */
    private String code;
    /** The auto-generated id of the LOINC code */
    private Long   id;
    /** The commonly-used name for the lab procedure */
    private String commonName;
    /** The substance or entity being measured or observed */
    private String component;
    /** The characteristic or attribute of the analyte */
    private String property;
    /** The type of result for this lab procedure */
    private String resultType;
    /** The maximum value for if the result is numeric */
    private String maximum;
    /** The minimum value for if the result is numeric */
    private String minimum;

    /**
     * Empty constructor for GSON
     */
    public LOINCForm () {

    }

    /**
     * Construct a form off an existing LOINC object
     *
     * @param code
     *            The object to fill this form with
     */
    public LOINCForm ( final LOINC code ) {
        setCode( code.getCode() );
        setCommonName( code.getCommonName() );
        setComponent( code.getComponent() );
        setProperty( code.getProperty() );
        setId( code.getId() );
        setResultType( code.getResultType().getType() );
        setMaximum( code.getMaximum() );
        setMinimum( code.getMinimum() );
    }

    /**
     * Gets the maximum set value for this test's results
     *
     * @return maximum set value for this test's results
     */
    public String getMaximum () {
        return maximum;
    }

    /**
     * Sets the maximum value for this test's results
     *
     * @param maximum
     *            Max value for this test's results
     */
    public void setMaximum ( final String maximum ) {
        this.maximum = maximum;
    }

    /**
     * Gets the minimum set value for this test's results
     *
     * @return Minimum set value for this test's results
     */
    public String getMinimum () {
        return minimum;
    }

    /**
     * Sets the minimum value for this test's results
     *
     * @param minimum
     *            set value for this test's results
     */
    public void setMinimum ( final String minimum ) {
        this.minimum = minimum;
    }

    /**
     * Sets the String representation of the code
     *
     * @param code
     *            The new code
     */
    public void setCode ( final String code ) {
        this.code = code;
    }

    /**
     * Returns the String representation of the code
     *
     * @return The code
     */
    public String getCode () {
        return code;
    }

    /**
     * Sets the common name of this code
     *
     * @param n
     *            The new common name
     */
    public void setCommonName ( final String n ) {
        commonName = n;
    }

    /**
     * Returns the common name of the code
     *
     * @return The common name
     */
    public String getCommonName () {
        return commonName;
    }

    /**
     * Sets the component of this code
     *
     * @param c
     *            The new component
     */
    public void setComponent ( final String c ) {
        component = c;
    }

    /**
     * Returns the component of the code
     *
     * @return The component
     */
    public String getComponent () {
        return component;
    }

    /**
     * Sets the property of this code
     *
     * @param p
     *            The new property
     */
    public void setProperty ( final String p ) {
        property = p;
    }

    /**
     * Returns the property of the code
     *
     * @return The property
     */
    public String getProperty () {
        return property;
    }

    /**
     * Sets the ID of the Code
     *
     * @param l
     *            The new ID of the Code. For Hibernate.
     */
    public void setId ( final Long l ) {
        id = l;
    }

    /**
     * Gets the result type for this lab procedure
     *
     * @return the result type for this lab procedure
     */
    public String getResultType () {
        return resultType;
    }

    /**
     * Sets the result type for this lab procedure
     *
     * @param resultType
     *            the enum object for the intended type
     */
    public void setResultType ( final String resultType ) {
        final ResultType[] enumArray = ResultType.values();
        final String[] enumStrings = new String[enumArray.length];
        for ( int i = 0; i < enumArray.length; i++ ) {
            enumStrings[i] = enumArray[i].getType();
        }

        for ( int i = 0; i < enumStrings.length; i++ ) {
            if ( enumStrings[i].equals( resultType ) ) {
                this.resultType = resultType;
                return;
            }
        }

        throw new IllegalArgumentException();
    }

    /**
     * Returns the ID of the Code
     *
     * @return The Lab Procedure ID
     */
    public Long getId () {
        return id;
    }

    @Override
    public boolean equals ( final Object o ) {
        if ( o instanceof LOINCForm ) {
            final LOINCForm f = (LOINCForm) o;
            return code.equals( f.getCode() ) && id.equals( f.getId() ) && commonName.equals( f.getCommonName() )
                    && component.equals( f.getComponent() ) && property.equals( f.getProperty() );
        }
        return false;
    }

}
