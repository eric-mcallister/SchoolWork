package edu.ncsu.csc.itrust2.cucumber;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.time.LocalDate;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import edu.ncsu.csc.itrust2.forms.admin.ICDCodeForm;
import edu.ncsu.csc.itrust2.models.enums.HouseholdSmokingStatus;
import edu.ncsu.csc.itrust2.models.enums.PatientSmokingStatus;
import edu.ncsu.csc.itrust2.models.enums.ResultType;
import edu.ncsu.csc.itrust2.models.enums.Role;
import edu.ncsu.csc.itrust2.models.persistent.DomainObject;
import edu.ncsu.csc.itrust2.models.persistent.GeneralCheckup;
import edu.ncsu.csc.itrust2.models.persistent.ICDCode;
import edu.ncsu.csc.itrust2.models.persistent.LOINC;
import edu.ncsu.csc.itrust2.models.persistent.Patient;
import edu.ncsu.csc.itrust2.models.persistent.Personnel;
import edu.ncsu.csc.itrust2.models.persistent.User;

/**
 * StepDefs to test the new UC24 Oral Glucose Tolerance Test functionality The
 * Gherkin which defines the flow of the StepDefs can be found in
 * OralGlucoseToleranceTest.feature
 *
 * @author Jonathan Fisher
 */
public class OralGlucoseToleranceTestStepDefs extends CucumberTest {

    private final String baseUrl = "http://localhost:8080/iTrust2";

    private final int    testID  = 0;

    /**
     * This method was taken from the SatisfactionSurveyStepDefs.java file From
     * my Guided Project, team 202-8, written by Ben Gray
     *
     * Asserts that the text is on the page
     *
     * @param text
     *            text to check
     */
    public void assertTextPresent ( final String text ) {
        try {
            assertTrue( driver.getPageSource().contains( text ) );
        }
        catch ( final Exception e ) {
            fail();
        }
    }

    /**
     * NOTA BENE: This method was copied from the
     * DocumentOfficeVisitStepDefs.java file, written by the CSC326 Teaching
     * Staff
     *
     * Fills in the date and time fields with the specified date and time.
     *
     * @param date
     *            The date to enter.
     * @param time
     *            The time to enter.
     */
    private void fillInDateTime ( final String dateField, final String date, final String timeField,
            final String time ) {
        fillInDate( dateField, date );
        fillInTime( timeField, time );
    }

    /**
     * NOTA BENE: This method was copied from the
     * DocumentOfficeVisitStepDefs.java file, written by the CSC326 Teaching
     * Staff
     *
     * Fills in the date field with the specified date.
     *
     * @param date
     *            The date to enter.
     */
    private void fillInDate ( final String dateField, final String date ) {
        driver.findElement( By.name( dateField ) ).clear();
        final WebElement dateElement = driver.findElement( By.name( dateField ) );
        dateElement.sendKeys( date.replace( "/", "" ) );
    }

    /**
     * NOTA BENE: This method was copied from the
     * DocumentOfficeVisitStepDefs.java file, written by the CSC326 Teaching
     * Staff
     *
     * Fills in the time field with the specified time.
     *
     * @param time
     *            The time to enter.
     */
    private void fillInTime ( final String timeField, String time ) {
        // Zero-pad the time for entry
        if ( time.length() == 7 ) {
            time = "0" + time;
        }

        driver.findElement( By.name( timeField ) ).clear();
        final WebElement timeElement = driver.findElement( By.name( timeField ) );
        timeElement.sendKeys( time.replace( ":", "" ).replace( " ", "" ) );
    }

    /**
     * Since database resets when testing, setup data explicitly for testing
     *
     * Idea for this resetDatabase() function taken from my Guided Project with
     * Ben Gray and Eric McAllister. Our Team was 202-08
     */
    @Given ( "^I am about to start testing$" )
    public void resetDatabase () {
        GeneralCheckup.deleteAll();
        @SuppressWarnings ( "rawtypes" )
        final DomainObject obj1 = DomainObject.getBy( ICDCode.class, "code", "E11.9" );
        if ( obj1 != null ) {
            obj1.delete();
        }
        @SuppressWarnings ( "rawtypes" )
        final DomainObject obj2 = DomainObject.getBy( ICDCode.class, "code", "R73.03" );
        if ( obj2 != null ) {
            obj2.delete();
        }

        // Create a user for the purpose of testing new functionality.
        // The user is an adult and can have procedures recommended for them
        final Patient procPatient = new Patient();
        procPatient.setFirstName( "procPatient" );
        final User procPatientUser = new User( "procPatient",
                "$2a$10$EblZqNptyYvcLm/VwDCVAuBjzZOI7khzdyGPBr08PpIi0na624b8.", Role.ROLE_PATIENT, 1 );
        procPatientUser.save();
        procPatient.setSelf( procPatientUser );
        procPatient.setLastName( "Patient for Procedures" );
        procPatient.setDateOfBirth( LocalDate.now().minusYears( 20 ) );
        procPatient.save();

        // Create a labtech user for the purpose of testing new functionality.
        final User labTech = new User( "newLabtech", "$2a$10$EblZqNptyYvcLm/VwDCVAuBjzZOI7khzdyGPBr08PpIi0na624b8.",
                Role.ROLE_LABTECH, 1 );
        labTech.save();
        final Personnel labTechPerson = new Personnel();
        labTechPerson.setSelf( labTech );
        labTechPerson.setFirstName( "newLab" );
        labTechPerson.setLastName( "Technician" );
        labTechPerson.save();

        // Now, lets create the necessary procedure
        final LOINC l = new LOINC();
        l.setCode( "62856-0" );
        l.setCommonName( "Oral Glucose Tolerance Test" );
        l.setComponent( "Blood Sugar" );
        l.setProperty( "mg/dl" );
        l.setResultType( ResultType.QUANTITATIVE );
        l.setMinimum( "0" );
        l.setMaximum( "1250" );
        l.save();

        // Now, we need to make the ICD-10 codes
        ICDCodeForm codeForm = new ICDCodeForm();
        codeForm.setCode( "E11.9" );
        codeForm.setDescription( "Diabetes" );
        final ICDCode diabetes = new ICDCode( codeForm );
        diabetes.save();

        codeForm = new ICDCodeForm();
        codeForm.setCode( "R73.03" );
        codeForm.setDescription( "Pre-Diabetes" );
        final ICDCode prediabetes = new ICDCode( codeForm );
        prediabetes.save();
    }

    /**
     * Log into iTrust2 as the default HCP user
     */
    @Given ( "^I log into the iTrust2 system as an HCP$" )
    public void loginAsHCP () {
        attemptLogout();
        driver.get( baseUrl );
        final WebElement username = driver.findElement( By.name( "username" ) );
        username.clear();
        username.sendKeys( "hcp" );
        final WebElement password = driver.findElement( By.name( "password" ) );
        password.clear();
        password.sendKeys( "123456" );
        final WebElement submit = driver.findElement( By.className( "btn" ) );
        submit.click();
        waitForAngular();

        // Ensure the welcome text for the user is present to ensure we are
        // logged in
        assertTextPresent( "Welcome to iTrust2 - HCP" );
    }

    /**
     * Login as the default labtech user
     */
    @Given ( "^I log into the iTrust2 system as a LabTech$" )
    public void loginAsLabTech () {
        attemptLogout();
        driver.get( baseUrl );
        final WebElement username = driver.findElement( By.name( "username" ) );
        username.clear();
        username.sendKeys( "newLabtech" );
        final WebElement password = driver.findElement( By.name( "password" ) );
        password.clear();
        password.sendKeys( "123456" );
        final WebElement submit = driver.findElement( By.className( "btn" ) );
        submit.click();
        waitForAngular();

        // Ensure the welcome text for the user is present to ensure we are
        // logged in
        assertTextPresent( "Welcome to iTrust2 - Lab Tech" );
    }

    /**
     * Use Selenium to view the pending tests
     */
    @And ( "^am viewing my pending Tests$" )
    public void navigateToPendingTests () {
        ( (JavascriptExecutor) driver ).executeScript( "document.getElementById('LTprocedures').click();" );
        waitForAngular();
        assertTextPresent( "Lab Procedures" );
    }

    /**
     * Fill in the office visit field
     */
    @When ( "^I document an office visit for the test patient$" )
    public void createBasicOfficeVisit () {
        ( (JavascriptExecutor) driver ).executeScript( "document.getElementById('documentOfficeVisit').click();" );
        try {
            Thread.sleep( 1000 );
        }
        catch ( final InterruptedException e ) {
            e.printStackTrace();
        }

        // Make the first office visit
        // This was essentially copied from DocumentOfficeVisitStepDefs.java,
        // written by the teaching staff

        // Choose the new test patient
        /*
         * try { Thread.sleep( 15000 ); } catch ( final InterruptedException e )
         * { // TODO Auto-generated catch block e.printStackTrace(); }
         */
        final WebElement patient = driver.findElement( By.name( "name" ) );
        patient.click();

        final WebElement type = driver.findElement( By.name( "GENERAL_CHECKUP" ) );
        type.click();

        final WebElement hospital = driver.findElement( By.name( "hospital" ) );
        hospital.click();

        fillInDateTime( "date", "10/01/2019", "time", "9:30 AM" );

        waitForAngular();

        final WebElement heightElement = driver.findElement( By.name( "height" ) );
        heightElement.clear();
        heightElement.sendKeys( "120" );

        final WebElement weightElement = driver.findElement( By.name( "weight" ) );
        weightElement.clear();
        weightElement.sendKeys( "120" );

        final WebElement systolicElement = driver.findElement( By.name( "systolic" ) );
        systolicElement.clear();
        systolicElement.sendKeys( "100" );

        final WebElement diastolicElement = driver.findElement( By.name( "diastolic" ) );
        diastolicElement.clear();
        diastolicElement.sendKeys( "100" );

        final WebElement hdlElement = driver.findElement( By.name( "hdl" ) );
        hdlElement.clear();
        hdlElement.sendKeys( "90" );

        final WebElement ldlElement = driver.findElement( By.name( "ldl" ) );
        ldlElement.clear();
        ldlElement.sendKeys( "100" );

        final WebElement triElement = driver.findElement( By.name( "tri" ) );
        triElement.clear();
        triElement.sendKeys( "100" );

        final WebElement houseSmokeElement = driver.findElement(
                By.cssSelector( "input[value=\"" + HouseholdSmokingStatus.NONSMOKING.toString() + "\"]" ) );
        houseSmokeElement.click();

        final WebElement patientSmokeElement = driver
                .findElement( By.cssSelector( "input[value=\"" + PatientSmokingStatus.NEVER.toString() + "\"]" ) );
        patientSmokeElement.click();

        // Ensure that the "Oral Glucose Tolerance Test" text shows up. If it
        // does
        // That means we have filled out the forms correctly and can choose the
        // procedure
        assertTextPresent( "Oral Glucose Tolerance Test" );
    }

    /**
     * Ensure that we cannot recommend a procedure for a young squirt without
     * choosing type of visit
     */
    @When ( "^I document an office visit without choosing type of visit$" )
    public void selectYoungPatient () {
        ( (JavascriptExecutor) driver ).executeScript( "document.getElementById('documentOfficeVisit').click();" );
        waitForAngular();

        // Make the first office visit
        // This was essentially copied from DocumentOfficeVisitStepDefs.java,
        // written by the teaching staff

        // Choose the new test patient
        final WebElement patient = driver.findElement( By.name( "name" ) );
        patient.click();

        final WebElement hospital = driver.findElement( By.name( "hospital" ) );
        hospital.click();

        fillInDateTime( "date", "10/01/2019", "time", "9:30 AM" );

        waitForAngular();

        // Should not see the Lab Procedures portion of this page when no type
        // of visit is chosen
        try {
            Thread.sleep( 1000 );
        }
        catch ( final InterruptedException e ) {
            e.printStackTrace();
        }
        boolean labProceduresShown = false;
        try {
            labProceduresShown = driver.findElement( By.partialLinkText( "Lab Procedures" ) ).isDisplayed();
            assertFalse( labProceduresShown );
        }
        catch ( final NoSuchElementException e ) {
            // We expect to have an exception, since this text should NOT be on
            // the page yet
            // Therefore, if we get in here, our test is actually passing
            assertFalse( labProceduresShown );
        }
    }

    /**
     * Select the only lab procedure on the list
     */
    @When ( "^I select the procedure to complete$" )
    public void selectProcedure () {
        final WebElement update = driver.findElement( By.id( "update-62856-0" ) );
        update.click();
        waitForAngular();
        assertTextPresent( "Update Lab Procedure" );
    }

    /**
     * Navigate to past office visits and view the results of one
     */
    @When ( "^I view a past office visit which included an Oral Glucose Tolerance Test$" )
    public void viewPastOfficeVisit () {
        ( (JavascriptExecutor) driver ).executeScript( "document.getElementById('editOfficeVisit').click();" );
        waitForAngular();

        try {
            Thread.sleep( 5000 );
        }
        catch ( final InterruptedException e ) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        final WebElement pastVisit = driver.findElement( By.className( "editVisitSelector" ) );
        pastVisit.click();

        // Ensure that the visit was properly loaded.
        // If it was, then the Lab Procedures section will be showing
        assertTextPresent( "Lab Procedures" );
    }

    /**
     * Recommend the oral glucose tolerance test to the patient
     */
    @And ( "^recommend the oral glucose tolerance test to the patient$" )
    public void recommendProcedure () {
        final WebElement procedure = driver.findElement( By.name( "Oral Glucose Tolerance Test" ) );
        procedure.click();
        final Select dropdown = new Select( driver.findElement( By.name( "priority" ) ) );
        dropdown.selectByVisibleText( "Medium" );

        // Ensure we clicked the right element
        assertTextPresent( "Medium" );

        final WebElement labtech = driver.findElement( By.name( "newLabtech" ) );
        labtech.click();

        final WebElement notesField = driver.findElement( By.name( "procNotes" ) );
        notesField.clear();
        notesField.sendKeys( "Initiate Sugary Beverage Sequence" );

        final WebElement addProcedure = driver.findElement( By.name( "addProcedure" ) );
        addProcedure.click();
        waitForAngular();

        // Assert that some of the text which shows up when displaying
        // procedures show up
        assertTextPresent( "Lab procedure added successfully" );
    }

    /**
     * Save the office visit
     */
    @And ( "^save the office visit$" )
    public void saveOfficeVisit () {
        final WebElement addProcedure = driver.findElement( By.name( "submit" ) );
        addProcedure.click();
        waitForAngular();
    }

    /**
     * Fill in an invalid Oral Glucose Tolerance Test result
     */
    @And ( "^fill in disallowed results of the procedure$" )
    public void fillInInvalidValue () {
        final Select dropdown = new Select( driver.findElement( By.id( "selectStatus" ) ) );
        dropdown.selectByVisibleText( "COMPLETED" );

        // Ensure we clicked the right element
        assertTextPresent( "COMPLETED" );

        final WebElement results = driver.findElement( By.name( "results" ) );
        results.clear();
        results.sendKeys( "hcp" );
    }

    /**
     * Save the lab procedure
     */
    @And ( "^save the lab procedure$" )
    public void saveLabTechResults () {
        final WebElement addProcedure = driver.findElement( By.name( "submit" ) );
        addProcedure.click();
        waitForAngular();

        // There really isn't anything to check here, all we are doing is
        // clicking
        // The save button. Let's ensure we are on the same page still?
        assertTextPresent( "Lab Procedures" );
    }

    /**
     * Fill in a valid Oral Glucose Tolerance Test result
     */
    @And ( "^fill in the correct results of the procedure$" )
    public void fillInCorrectResults () {
        final Select dropdown = new Select( driver.findElement( By.id( "selectStatus" ) ) );
        dropdown.selectByVisibleText( "COMPLETED" );

        // Ensure we clicked the right element
        assertTextPresent( "COMPLETED" );

        final WebElement results = driver.findElement( By.name( "results" ) );
        results.clear();
        results.sendKeys( "150" );
    }

    /**
     * Assert the confirmation message for saving an office visit shows up
     */
    @Then ( "^the office visit is successfully saved$" )
    public void confirmVisitSaved () {
        assertTextPresent( "Office visit created successfully" );
    }

    /**
     * Ensure that we cannot choose the lab procedure Since our test patient is
     * < 3 years old and we didn't choose a type of visit
     */
    @Then ( "^I cannot choose a lab procedure$" )
    public void ensureCannotChooseProcedure () {
        // Should not see the Lab Procedures portion of this page for a user
        // only one year old
        boolean labProceduresShown = false;
        try {
            labProceduresShown = driver.findElement( By.partialLinkText( "Oral Glucose" ) ).isDisplayed();
            assertFalse( labProceduresShown );
        }
        catch ( final NoSuchElementException e ) {
            // We expect to have an exception, since this text should NOT be on
            // the page yet
            // Therefore, if we get in here, our test is actually passing
            assertFalse( labProceduresShown );
        }
    }

    /**
     * Ensure that entering the wrong type of result in the results field
     * doesn't save
     */
    @Then ( "^I am told that the results were not successfully saved$" )
    public void ensureResultsNotSaved () {
        assertTextPresent( "Results must be a number" );
    }

    /**
     * Ensure that the assigned test is still present but has no results
     */
    @Then ( "^I see that the test is still pending$" )
    public void ensureTestPending () {
        waitForAngular();

        // Ensure the results of 150 mg/dl are not shown
        boolean resultsShown = false;
        try {
            resultsShown = driver.findElement( By.partialLinkText( "150" ) ).isDisplayed();
            assertFalse( resultsShown );
        }
        catch ( final NoSuchElementException e ) {
            // We expect to have an exception, since this text should NOT be on
            // the page yet
            // Therefore, if we get in here, our test is actually passing
            assertFalse( resultsShown );
        }
    }

    /**
     * Confirm that our result of 150mg/dl was saved
     */
    @Then ( "^I am told that the results were successfully saved$" )
    public void confirmResultsSaved () {
        // Ensure the confirm message shows up
        assertTextPresent( "Successfully updated procedure" );
        // Ensure that the results show up
        assertTextPresent( "150" );
    }

    /**
     * Ensure that we have marked the status of the completed lab test As
     * complete, and that the results show up properly
     *
     * @throws InterruptedException
     */
    @Then ( "^I see the Oral Glucose Tolerance Test results have been completed$" )
    public void confirmStatusComplete () throws InterruptedException {
        // Ensure the confirm message shows up
        Thread.sleep( 10000 );
        assertTextPresent( "COMPLETED" );
        // Ensure the results show up
        assertTextPresent( "150" );
    }

    /**
     * Confirm that the procedure is listed on the saved office visit
     */
    @And ( "^the oral glucose tolerance test is added to the list of procedures$" )
    public void confirmProceduresPresent () {
        assertTextPresent( "62856-0" );
    }

    /**
     * Ensure that we can try again to edit the results if we enter the wrong
     * initial value
     */
    @And ( "^I can still edit the procedure results$" )
    public void ensureUpdateStillValid () {
        assertTextPresent( "Update Lab Procedure" );
    }

    /**
     * One of the new features is automatically suggesting a diagnosis. We will
     * ensure the correct diagnosis message is shown
     *
     * @throws InterruptedException
     */
    @And ( "^a diabetes diagnosis has been automatically suggested$" )
    public void confirmAutoDiagnosis () throws InterruptedException {
        Thread.sleep( 10000 );
        assertTextPresent(
                "Diagnosis of R73.03 automatically selected based on results of the 62856-0 test. HCP Must Confirm." );
    }
}
