/**
 * API tests that verify that different functionality provided by the REST API
 * is working properly.
 * 
 * @author Kai Presler-Marshall
 */
package edu.ncsu.csc.itrust2.apitest;
